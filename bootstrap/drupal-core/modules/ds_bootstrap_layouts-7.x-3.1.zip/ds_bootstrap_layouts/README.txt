
-- SUMMARY --

Display Suite Boootstrap layouts adds several most common layouts for Display
Suite, all using splendid Twitter Bootstrap grid system.

For more info about Twitter Bootstrap and it's scaffolding system check out:
  http://twitter.github.io/bootstrap/scaffolding.html

To submit bug reports and feature suggestions, or to track changes go to:
  http://drupal.org/project/issues/2013537


-- REQUIREMENTS --

Display Suite
  http://drupal.org/project/DS

A Twitter Bootstrap theme such as:
  http://drupal.org/project/bootstrap


-- INSTALLATION --

Install as usual, see http://drupal.org/node/70151 for further information.


-- CONTACT --

Branislav Bujisic - http://drupal.org/user/52799


-- THANKS TO --

CIRCLE WEB FOUNDRY
  Small south-european Drupal shop with strong urge to acquire and apply all the
  fancy new technology. Visit http://www.circlewf.com for more information.

PEOPLEMATTER
  HR SAAS provider specialized in service industry. Working on their project
  http://www.peoplematter.com resulted in idea to develop the module.